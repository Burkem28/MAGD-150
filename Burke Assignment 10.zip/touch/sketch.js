let gui;

let bg = 210;
let button;
let checkbox;
let slider;
cloudX = 60;

function setup() {
  createCanvas(600, 700);
  background(80);
  gui = createGui();
  
  button = createButton("Day/Night", 50, 625, 110, 50);
  checkbox = createCheckbox("checkbox", 250, 640, 50, 50);
  slider = createSlider("Slider", 350, 625, 200, 32, 100, 300);

}

function draw() {
  background(bg);
  strokeWeight(1);
  stroke(1);
  strokeCap(SQUARE);
  
  // buildings
  fill(150);
  rect(200, 300, 250, 300);
  
  fill(225);
  rect(100, 90, 100, 510);
  
  fill(300);
  rect(0, 350, 100, 250);
  
  fill(50);
  rect(450, 150, 200, 450);
  
  
  // doors
  fill(180);
  rect(350, 500, 50, 100);
  rect(145, 500, 50, 100);
  rect(35, 510, 50, 90);
  rect(500, 520, 50, 80);
  
  
  // knobs
  strokeWeight(8);
  fill(140);
  point(390, 560);
  point(185, 560);
  point(540, 560);
  point(72, 560);
  
  
  // windows
  fill(180);
  strokeWeight(2);
  rect(250, 350, 80, 80);
  rect(155, 350, 40, 40);
  rect(105, 350, 40, 40);
  rect(155, 400, 40, 40);
  rect(105, 400, 40, 40);
  rect(155, 300, 40, 40);
  rect(105, 300, 40, 40);
  rect(155, 250, 40, 40);
  rect(105, 250, 40, 40);
  rect(155, 200, 40, 40);
  rect(105, 200, 40, 40);
  rect(155, 150, 40, 40);
  rect(105, 150, 40, 40);
  rect(155, 100, 40, 40);
  rect(105, 100, 40, 40);
  rect(155, 450, 40, 40);
  rect(105, 450, 40, 40);
  rect(460, 160, 60, 60);
  rect(530, 160, 60, 60);
  rect(460, 230, 60, 60);
  rect(530, 230, 60, 60);
  rect(460, 300, 60, 60);
  rect(530, 300, 60, 60);
  rect(460, 370, 60, 60);
  rect(530, 370, 60, 60);
  rect(460, 440, 60, 60);
  rect(530, 440, 60, 60);
  rect(5, 360, 40, 40);
  rect(55, 360, 40, 40);
  rect(5, 410, 40, 40);
  rect(55, 410, 40, 40);
  rect(5, 460, 40, 40);
  rect(55, 460, 40, 40);
  
  // horizonal window dividers
  line(290, 350, 290, 430);
  line(175, 200, 175, 240);
  line(125, 200, 125, 240);
  line(175, 250, 175, 290);
  line(125, 250, 125, 290);
  line(175, 300, 175, 340);
  line(125, 300, 125, 340);  
  line(175, 350, 175, 390);
  line(125, 350, 125, 390);
  line(175, 400, 175, 440);
  line(125, 400, 125, 440);
  line(175, 450, 175, 490);
  line(125, 450, 125, 490);
  line(175, 150, 175, 190);
  line(125, 150, 125, 190);
  line(175, 100, 175, 140);
  line(125, 100, 125, 140);
  line(590, 190, 530, 190);
  line(520, 190, 460, 190);
  line(590, 260, 530, 260);
  line(520, 260, 460, 260);
  line(590, 330, 530, 330);
  line(520, 330, 460, 330);
  line(590, 400, 530, 400);
  line(520, 400, 460, 400);
  line(590, 470, 530, 470);
  line(520, 470, 460, 470);
  line(6, 380, 45, 380);
  line(56, 380, 95, 380);
  line(6, 430, 45, 430);
  line(56, 430, 95, 430);
  line(6, 480, 45, 480);
  line(56, 480, 95, 480);
  
  
  //vertical window dividers
  line(250, 390, 330, 390);
  line(105, 470, 145, 470);
  line(155, 470, 195, 470);
  line(105, 420, 145, 420);
  line(155, 420, 195, 420);
  line(105, 370, 145, 370); 
  line(155, 370, 195, 370); 
  line(105, 320, 145, 320); 
  line(155, 320, 195, 320);
  line(105, 270, 145, 270); 
  line(155, 270, 195, 270);
  line(105, 220, 145, 220); 
  line(155, 220, 195, 220);
  line(105, 120, 145, 120);
  line(155, 120, 195, 120);
  line(105, 170, 145, 170); 
  line(155, 170, 195, 170);
  line(560, 160, 560, 220);
  line(490, 160, 490, 220);
  line(560, 230, 560, 290);
  line(490, 230, 490, 290);
  line(560, 300, 560, 360);
  line(490, 300, 490, 360);  
  line(560, 370, 560, 430);
  line(490, 370, 490, 430);
  line(560, 440, 560, 500);
  line(490, 440, 490, 500);
  line(25, 360, 25, 400);
  line(75, 360, 75, 400);
  line(25, 410, 25, 450);
  line(75, 410, 75, 450);
  line(25, 460, 25, 500);
  line(75, 460, 75, 500);
  
  
  
  // chimney
  fill(180);
  rect(375, 240, 40, 60);

  
  // chimney cap
  strokeWeight(5);
  strokeCap(ROUND);
  line(370, 240, 420, 240);
  
  
  // clouds
  fill(255);
  noStroke();

  ellipse(cloudX, 40, 60, 50);

  ellipse(cloudX+30, 40, 70, 50);
 
  ellipse(cloudX, 50, 60, 50);

  ellipse(cloudX, 50, 70, 50);
  
  drawGui();
  
  if(checkbox.val == 0){

    cloudX = slider.val;

    if(button.isPressed){

      bg = 100;
    }
  
    if(button.isReleased){
      bg = 210;
    } 
    textSize(20);
    fill(0);
    text("Disable", 240, 625);
  }
  else{
    textSize(20);
    fill(0);
    text("Enable", 240, 625);
  }
}
 

